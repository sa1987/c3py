class PolicyManagement(object):

    def __init__(self, client):
        self.client = client

    def viewPolicies(self):
        uri = "/v1/policies"
        response = self.client.get(uri)
        return response

    def createActionPolicy(self, payLoad):
        uri = "/v1/actionpolicies"
        response = self.client.post(uri, payLoad)
        return response

    def enableActionPolicy(self, actionPolicyId, userId=None):
        payLoad = {"action":"ENABLE_POLICY", "userId":1 }
        if userId:
            payLoad["userId"] = userId
        uri = "/v1/actionpolicies/" + str(actionPolicyId)
        response = self.client.post(uri, payLoad)
        return response

    def disableActionPolicy(self, actionPolicyId, userId=None):
        payLoad = {"action":"DISABLE_POLICY", "userId":1 }
        if userId:
            payLoad["userId"] = userId
        uri = "/v1/actionpolicies/" + str(actionPolicyId)
        response = self.client.post(uri, payLoad)
        return response

    def viewActionPolicy(self, actionPolicyId=None):
        uri = "/v1/actionpolicies/"
        if actionPolicyId != None:
            uri = uri + str(actionPolicyId)
        response = self.client.get(uri)
        return response

    def updateActionPolicy(self, actionPolicyId, payLoad):
        uri = "/v1/actionpolicies/"
        if actionPolicyId != None:
            uri = uri + str(actionPolicyId)
        response = self.client.put(uri, payLoad)
        return response

    def deleteActionPolicy(self, actionPolicyId):
        uri = "/v1/actionpolicies/"
        uri = uri + str(actionPolicyId)
        response = self.client.delete(uri)
        return response
