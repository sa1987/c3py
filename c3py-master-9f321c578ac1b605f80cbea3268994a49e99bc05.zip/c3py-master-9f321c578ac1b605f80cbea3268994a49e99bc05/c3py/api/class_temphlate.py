class example(object):

    def __init__(self, client):
        self.client = client

#GET
    def GET(self):
        uri = ""
        response = self.client.get(uri)
        return response

    def POST(self, payLoad):
        uri = ""
        response = self.client.post(uri, payLoad)
        return response

    def PUT(self, payLoad):
        uri = ""
        response = self.client.put(uri, payLoad)
        return response

    def deleteAction(self, actionId):
        """
        """
        uri = "/v1/actions/" + str(actionId)
        response = self.client.delete(uri)
        return response
