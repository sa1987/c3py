from c3_api import c3Api
import json

def pp_json(json_thing, sort=True, indents=4):
    if type(json_thing) is str:
        print(json.dumps(json.loads(json_thing), sort_keys=sort, indent=indents))
    else:
        print(json.dumps(json_thing, sort_keys=sort, indent=indents))
    return None

address = "https://10.127.193.121"
user = "cliqradmin"
key = "2A661A771F8B1205"

CloudCenter = c3Api(address,user,key)

#payLoad = json.load(open('payLoads/updateActionPolicy.json'))
#payLoad = json.load(open('payLoads/createActionPolicy.json'))

#request = CloudCenter.policyManagement.createActionPolicy(payLoad)
#request = CloudCenter.policyManagement.viewActionPolicy(4)
#request = CloudCenter.policyManagement.updateActionPolicy(4,payLoad)
#request = CloudCenter.policyManagement.enableActionPolicy(4,userId=2)
#request = CloudCenter.policyManagement.disableActionPolicy(4,userId=2)
#request = CloudCenter.policyManagement.deleteActionPolicy(4)
#request = CloudCenter.ACLManagement.viewACLEntities()

#pp_json(request.json())
#print(request.status_code)
#print(type(payLoad))

CloudCenter.ApplicationManagement.exportApplicationProfiles(2, 3, 4, 5)
