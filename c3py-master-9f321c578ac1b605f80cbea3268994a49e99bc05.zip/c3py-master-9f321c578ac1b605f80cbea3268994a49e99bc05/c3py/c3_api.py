from client import Client
from api.PolicyManagement import PolicyManagement
from api.ACLManagement import ACLManagement
from api.ActionManagement import ActionManagement
from api.ActivationProfilesManagement import ActivationProfilesManagement
from api.ApplicationManagement import ApplicationManagement

class c3Api(object):
    def __init__(self, address=None, user=None, apiKey=None):
        self.address = address
        self.user = user
        self.apiKey = apiKey
        self.client = Client(self.address, self.user, self.apiKey)

        self.PolicyManagement = PolicyManagement(self.client)
        self.ACLManagement = ACLManagement(self.client)
        self.ActivationProfilesManagement = ActivationProfilesManagement(self.client)
        self.ApplicationManagement = ApplicationManagement(self.client)
